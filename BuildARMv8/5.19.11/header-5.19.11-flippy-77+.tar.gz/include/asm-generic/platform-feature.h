/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_GENERIC_PLATFORM_FEATURE_H
#define _ASM_GENERIC_PLATFORM_FEATURE_H

/* Number of arch specific feature flags. */
#define PLATFORM_ARCH_FEAT_N	0

#endif /* _ASM_GENERIC_PLATFORM_FEATURE_H */
