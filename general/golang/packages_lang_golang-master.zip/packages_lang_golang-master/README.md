# OpenWrt golang latest version

## How to use?

```shell
rm -rf feeds/packages/lang/golang
svn export https://github.com/sbwml/packages_lang_golang/trunk feeds/packages/lang/golang
```
